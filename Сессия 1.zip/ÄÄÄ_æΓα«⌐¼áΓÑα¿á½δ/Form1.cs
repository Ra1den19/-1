﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ООО_Стройматериалы
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_вход_Click(object sender, EventArgs e)
        {
            try
            {
                string login = textBox_логин.Text;
                string password = textBox_пароль.Text;
                string connectionString = $@"Data Source = KAB17-06\SQLEXPRESS; Initial Catalog = Trade; Integrated Security = True";
                SqlConnection con = new SqlConnection(connectionString);
                string query = $"select * from Users where UserLogin = '{login}' and UserPassword = '{password}'";
                SqlCommand com = new SqlCommand(query, con);
                con.Open();

                SqlDataReader rd = com.ExecuteReader();
                if (rd.HasRows)
                {
                    while (rd.Read())
                    {
                        string role = rd["UserRole"].ToString();
                        if (role == "3")
                        {
                            DialogResult result = MessageBox.Show("Вы успешно авторизованы", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ClientForm cf = new ClientForm();
                            cf.ShowDialog();
                        }
                        if (role == "2")
                        {
                            DialogResult result = MessageBox.Show("Вы успешно авторизованы", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            ManagerForm mf = new ManagerForm();
                            mf.ShowDialog();
                        }
                        if (role == "1")
                        {
                            DialogResult result = MessageBox.Show("Вы успешно авторизованы", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            AdminForm af = new AdminForm();
                            af.ShowDialog();
                        }
                    }
                }
                else
                {
                    DialogResult result = MessageBox.Show("Неверный логин или пароль", "Сообщение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch(Exception ex)
            {
                DialogResult result = MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_войти_как_гость_Click(object sender, EventArgs e)
        {
            ClientForm cf = new ClientForm();
            cf.ShowDialog();
        }
    }
}
